
#include "Client.h"

using namespace std;
int main() {
	Client c;
	c.Test();
}