#include "IRobot.h"

IRobot::~IRobot() {}
