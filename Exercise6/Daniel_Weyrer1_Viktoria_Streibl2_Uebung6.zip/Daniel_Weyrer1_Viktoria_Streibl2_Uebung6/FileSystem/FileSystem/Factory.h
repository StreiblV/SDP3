/* ______________________________________________________________________
| Workfile : Factory.h
| Description : [ HEADER ]
| Name : Daniel Weyrer			PKZ : S1820306044
| Date : 16.12.2019
| Remarks : -
| Revision : 0
| _______________________________________________________________________ */

#ifndef FACTORY_H
#define FACTORY_H

class Factory {
};

#endif //!FACTORY_H